package com.yash.InternBusinessApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternBusinessAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
