package com.yash.spring.aop.second;

public interface CustomerService {
	
	public void addCustomer();
	public void updateCustomer();

}
