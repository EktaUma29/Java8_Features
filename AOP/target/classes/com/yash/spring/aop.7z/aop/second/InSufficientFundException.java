package com.yash.spring.aop.second;

public class InSufficientFundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
