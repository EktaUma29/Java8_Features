package com.yash.spring.aop;

public interface CustomerService {
	
	public void addCustomer();
	public void updateCustomer();

}
